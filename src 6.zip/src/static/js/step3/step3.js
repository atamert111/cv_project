document.addEventListener("DOMContentLoaded", function () {
    const selectedTemplateInput = document.getElementById("selectedTemplate");
    const buttons = document.querySelectorAll(".select-btn");
    const containers = document.querySelectorAll(".carousel-container");
    const images = document.querySelectorAll(".carousel img");
    const prevButton = document.getElementById("prevStep");
    const nextButton = document.getElementById("nextStep");

    // Başlangıçta "Sonraki" butonu devre dışı
    nextButton.disabled = true;

    // Seçili şablonu güncelleyen fonksiyon
    function updateSelection(template) {
        selectedTemplateInput.value = template;

        // Önce tüm şablonları temizle
        containers.forEach(container => container.classList.remove("selected"));
        buttons.forEach(btn => btn.classList.remove("selected"));
        images.forEach(img => img.classList.remove("selected"));

        // Seçilen şablona sınıf ekle
        const selectedContainer = document.querySelector(`.carousel-container img[data-template="${template}"]`).parentElement;
        const selectedBtn = document.querySelector(`.select-btn[data-template="${template}"]`);
        const selectedImage = document.querySelector(`.carousel-container img[data-template="${template}"]`);

        if (selectedContainer) selectedContainer.classList.add("selected");
        if (selectedBtn) selectedBtn.classList.add("selected");
        if (selectedImage) selectedImage.classList.add("selected");

        // Seçildiğinde yeşil tik çıksın
        const indicator = selectedContainer.querySelector(".selection-indicator");
        if (indicator) {
            indicator.style.display = "flex";
        }

        // Seçim yapıldığında "Sonraki" butonu aktif olsun
        nextButton.disabled = false;
    }

    // Sayfa yüklendiğinde önceki seçim varsa göster
    if (selectedTemplateInput.value) {
        updateSelection(selectedTemplateInput.value);
    }

    // Şablon seçme butonlarına event listener ekleme
    buttons.forEach(button => {
        button.addEventListener("click", function (event) {
            event.preventDefault(); // Formun otomatik gönderilmesini engelle
            const template = this.getAttribute("data-template");
            updateSelection(template);
        });
    });

    // Resme tıklanınca büyütme ve küçültme özelliği
    images.forEach(img => {
        img.addEventListener("click", function () {
            if (this.classList.contains("active")) {
                this.classList.remove("active");
            } else {
                images.forEach(i => i.classList.remove("active")); // Önce diğer aktifleri temizle
                this.classList.add("active");
            }
        });
    });

    // "Geri" butonu işlevselliği
    prevButton.addEventListener("click", function () {
        window.history.back();
    });

    // "Sonraki" butonuna tıklanınca form gönderilecek
    nextButton.addEventListener("click", function () {
        document.querySelector("form").submit();
    });
});
